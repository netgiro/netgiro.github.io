﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Kerfisvirkni.Pay.Web.DemoProvider.MvcApplication" Language="C#" %>
