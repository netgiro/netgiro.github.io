﻿/// <reference path="jquery-2.0.0.js" />
/// <reference path="jquery-ui-1.8.20.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="modernizr-2.5.3.js" />
/// <reference path="knockout-2.2.1.debug.js" />
