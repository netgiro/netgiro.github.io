﻿using System.Web;
using System.Web.Mvc;

namespace Kerfisvirkni.Pay.Web.DemoProvider
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}