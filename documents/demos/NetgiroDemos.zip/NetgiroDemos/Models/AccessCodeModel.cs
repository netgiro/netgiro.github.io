﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Models
{
    public class AccessCodeModel
    {
        public string RequestCode { get; set; }
        public string AccessCode { get; set; }
        public string UserId { get; set; }

        public bool Redirect { get; set; }
    }
}