﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Models
{
    public class PaymentSuccessModel
    {
        public string OrderId { get; set; }
        public string Signature { get; set; }
    }
}