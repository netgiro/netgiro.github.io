﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Caching;
using System.Web.Mvc;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Helpers
{
    public static class SessionHelpers
    {        
        public static void SaveProviderSessionToken(this Controller controller, string token)
        {
            controller.HttpContext.Session.Add("SessionToken", token);            
        }

        public static string GetProviderSessionToken(this Controller controller)
        {
            return (string)controller.HttpContext.Session["SessionToken"];
        }
        
    }

    public static class CacheHelper
    {
        public static void SaveAccessTokenRequest(this Controller controller, string sessionToken, string requestKey)
        {
            System.Web.HttpContext.Current.Cache[requestKey] = sessionToken;
        }

        public static string GetSessionTokenForAccessTokenRequest(this Controller controller, string requestKey)
        {
            var value = System.Web.HttpContext.Current.Cache[requestKey];
            return (string)value;
        }

        public static void SaveAccessTokenForSession(this Controller controller, string sessionToken, string accessToken)
        {
            System.Web.HttpContext.Current.Cache["at_" + sessionToken] = accessToken;
        }

        public static string GetAcessTokenForSession(this Controller controller, string sessionToken)
        {
            var value = System.Web.HttpContext.Current.Cache["at_" + sessionToken];
            return (string)value;
        }
    }
}