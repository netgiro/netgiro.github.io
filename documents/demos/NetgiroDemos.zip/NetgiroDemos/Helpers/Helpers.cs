﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Security.Cryptography;
using System.IO;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Helpers
{
    public static class Helpers
    {
        /// <summary>
        /// Returns query string created from dictionary values
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToQueryString(this Dictionary<string, string> value)
        {
            StringBuilder queryString = new StringBuilder();

            if (value == null || !value.Any())
                return queryString.ToString();

            queryString.Append("?");

            foreach (string key in value.Keys)
                queryString.Append(string.Format("{0}={1}&", HttpUtility.UrlEncode(key), HttpUtility.UrlEncode(value[key])));

            return queryString.ToString().TrimEnd('&');
        }

        private static void GetKeyAndIVFromSecretKey(byte[] secretKey, out byte[] key, out byte[] iv)
        {
            byte[] aesKey = new byte[32];
            byte[] aesIV = new byte[16];

            for (int i = 0; i < 32; i++)
                aesKey[i] = secretKey[i];

            for (int i = 32; i < 48; i++)
                aesIV[i - 32] = secretKey[i];

            key = aesKey;
            iv = aesIV;
        }

        public static string Encrypt(this string value, string secretKey)
        {
            try
            {
                // Create a MemoryStream.
                MemoryStream mStream = new MemoryStream();

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).                

                var key =  System.Convert.FromBase64String(secretKey);
                byte[] aesKey = new byte[32];
                byte[] aesIV = new byte[16];
                GetKeyAndIVFromSecretKey(key,out aesKey, out aesIV);

                CryptoStream cStream = new CryptoStream(mStream,
                    new AesCryptoServiceProvider().CreateEncryptor(aesKey, aesIV),
                    CryptoStreamMode.Write);

                // Convert the passed string to a byte array.
                byte[] toEncrypt = new UTF8Encoding().GetBytes(value);

                // Write the byte array to the crypto stream and flush it.
                cStream.Write(toEncrypt, 0, toEncrypt.Length);
                cStream.FlushFinalBlock();

                // Get an array of bytes from the 
                // MemoryStream that holds the 
                // encrypted data.
                byte[] ret = mStream.ToArray();

                // Close the streams.
                cStream.Close();
                mStream.Close();

                // Return the encrypted buffer.
                return System.Convert.ToBase64String(ret);
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }

        public static string Decrypt(this string value, string secretKey)
        {
            try
            {
                // Create a new MemoryStream using the passed 
                // array of encrypted data.
                byte[] data = System.Convert.FromBase64String(value);
                var key = System.Convert.FromBase64String(secretKey);
                byte[] aesKey = new byte[32];
                byte[] aesIV = new byte[16];
                GetKeyAndIVFromSecretKey(key, out aesKey, out aesIV);

                MemoryStream msDecrypt = new MemoryStream(data);

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).
                CryptoStream csDecrypt = new CryptoStream(msDecrypt,
                    new AesCryptoServiceProvider().CreateDecryptor(aesKey, aesIV),
                    CryptoStreamMode.Read);

                // Create buffer to hold the decrypted data.
                byte[] fromEncrypt = new byte[data.Length];

                // Read the decrypted data out of the crypto stream
                // and place it into the temporary buffer.
                csDecrypt.Read(fromEncrypt, 0, fromEncrypt.Length);

                //Convert the buffer into a string and return it.
                string result = UTF8Encoding.UTF8.GetString(fromEncrypt);
                return result.TrimEnd('\0');
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }
    }
}