﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Kerfisvirkni.Pay.Web.DemoProvider.Helpers;
using Kerfisvirkni.Pay.Api;
using Kerfisvirkni.Pay.Common.Security;
using Kerfisvirkni.Pay.Web.DemoProvider.Models;
using WebMatrix.WebData;
using System.Text;
using Newtonsoft.Json;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Controllers
{
    public class DemoAPIController : Controller
    {
        static string appId = ConfigurationManager.AppSettings["AppId"];
        static string secretKey = ConfigurationManager.AppSettings["SecretKey"];
        static string apiUrl = ConfigurationManager.AppSettings["ApiUrl"];
        //instantiate the API with your applicationID and secret key. This is used for securing communication.
        NetGiroApi netgiroApi = new NetGiroApi(appId, secretKey, ConfigurationManager.AppSettings["NetGiroApi"]);

        public ActionResult Index()
        {
            ViewBag.Appid = appId;
            ViewBag.RequestUrl = Url.Action("AuthorizeUserTokenRequest", "DemoAPI", new { }, Request.Url.Scheme);
            //check if user has access token            
            //if not
            var sessionToken = this.GetProviderSessionToken();
            
            if(sessionToken != null && this.GetAcessTokenForSession(sessionToken) != null) 
            {
                return RedirectToAction("LoginSuccess");
            }
            else
            {   
                var response = netgiroApi.GetSessionToken();

                if (response.Success)
                {
                    this.SaveProviderSessionToken(response.Message);
                    TempData["SessionSecure"] = true;
                }
                if (this.User != null)
                    netgiroApi.Login(this.GetProviderSessionToken(), this.User.Identity.Name);

                return View();
            }
        }

        [HttpPost]
        public ActionResult Checkout(IEnumerable<CartItemModel> cartItems)
        {
            CheckoutModel model = new CheckoutModel();
            //add all items to netgiro cart - ou can also add items one by one when users puts them into basket
            netgiroApi.AddCartItems(this.GetProviderSessionToken(), cartItems.ToArray());
            var result = netgiroApi.Checkout(this.GetProviderSessionToken());

            return Json(new { options = result.Options, message = result.Message }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Buy(byte option)
        {
            //user must be logged in before buying - you can either register him(email, gsm, ssn, bank account number or debit card number)
            //if he already exists, he will be linked to his existing account
            netgiroApi.Login(this.GetProviderSessionToken(), this.User.Identity.Name);
            //payment process returns if it succeeded and message which contains reason if not
            var response = netgiroApi.BuyNowPayLater(this.GetProviderSessionToken(), option);

            return Json(new { success = response.Success, message = response.Message}, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Buy2(byte option)
        {
            //payment process returns if it succeeded and message which contains reason if not
            var response = netgiroApi.BuyNowPayLater(this.GetProviderSessionToken(), option);

            return Json(new { success = response.Success, message = response.Message }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult AuthorizeUserTokenRequest(bool redirect)
        {
            //generate request code
            string requestCode = DateTime.Now.Ticks.ToString();

            var sessionToken = this.GetProviderSessionToken();
            this.SaveAccessTokenRequest(sessionToken, requestCode);

            var urlParams = new Dictionary<string,string>();
            urlParams.Add("applicationId", appId);

            //Create payload object
            var payload = new
            {
                returnUrl = Url.Action("AuthorizeUserToken", "DemoAPI", new { }, Request.Url.Scheme),
                requestCode = requestCode,
                scope = "authenticate_user",                
                redirect = redirect,
                post = "true"
            };

            //Serialize and encrypt object
            string payloadJson = JsonConvert.SerializeObject(payload);
            var encryptedParams = payloadJson.Encrypt(secretKey);

            //Add serialized object to query string and return url back to script
            urlParams.Add("payload", encryptedParams);
            var url = apiUrl + urlParams.ToQueryString();
            return Json(new { success = true, url = url });
        }

        public ActionResult AuthorizeUserToken(string payload)
        {
            //Allow netgiro api to send response to us
            this.HttpContext.Response.AddHeader("Access-Control-Allow-Origin", apiUrl);
            //Check signature
            //var localSignature = netgiroApi.SignData(string.Format("{0}|{1}", code, accessCode));
            //if (signature != localSignature)
            //    //Response came from untrusted source log and discard
            //    return View("Error");            

            var decryptedPayload = payload.Decrypt(secretKey);
            var model = JsonConvert.DeserializeObject<AccessCodeModel>(decryptedPayload);
            
            //Verify session token with local version
            var sessionToken = this.GetSessionTokenForAccessTokenRequest(model.RequestCode);
            //Sign access token and call AuthorizeUser
            var accessCodeSigned = HMACDigest.SignData(model.AccessCode, secretKey);
            var result = netgiroApi.AuthorizeUser(sessionToken, new AuthorizeUserModel { AccessCode = model.AccessCode  });
            this.SaveAccessTokenForSession(sessionToken, model.AccessCode);

            if (result.Success && model.Redirect)
            {
                return View("LoginSuccess");
            }
            else
                return Json(new {success = result.Success});
        }

        public ActionResult AuthorizeUserLogin(string userid)
        {
            //Verify session token with local version
            var sessionToken = this.GetProviderSessionToken();
            //Sign access token and call AuthorizeUser
            var result = netgiroApi.ExternalLogin(sessionToken, userid );

            if (result.Success)
            {
                return Json(new { success = true, usertoken = result.Message });
                //User is logged in.. show him buy confirmation page
            }

            return Json(new { success = false });
        }

    }
}
