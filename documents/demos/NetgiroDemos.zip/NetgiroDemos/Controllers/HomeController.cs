﻿using System.Web.Mvc;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Controllers
{
    //[InitializeSimpleMembership]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //if (!User.Identity.IsAuthenticated)
            //    WebSecurity.Login("netgiro", "netgiro1", persistCookie: true);
            return RedirectToAction("Index", "DemoFrame");
            return View();
        }
    }
}
