﻿using System;
using System.Net.Http;
using Kerfisvirkni.Pay.Web.DemoProvider.Models;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace Kerfisvirkni.Pay.Web.DemoProvider.Controllers
{
    public class DemoFrameController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.ChargeAction = ConfigurationManager.AppSettings["ChargeAction"];
            return View();
        }

        public ActionResult Success(PaymentSuccessModel model)
        {
            string signature = CalculateSignature(ConfigurationManager.AppSettings["SecretKey"], model.OrderId);
            TempData.Add("Message", signature == model.Signature ? "Payment successful for order " + model.OrderId : "Payment failed");
            return RedirectToAction("Index");
        }

        public ActionResult Cancel(string orderId, string signature)
        {
            string localSignature = CalculateSignature(ConfigurationManager.AppSettings["SecretKey"], orderId);
            ViewBag.Message = signature == localSignature ? "Payment canceled" : "Payment failed";
            showMessage("Success", "You have canceled your previous buy. continue...", "Continue shopping");
            return RedirectToAction("Index","DemoFrame");
        }

        public ActionResult Confirm(string orderId, string signature)
        {
            string localSignature = CalculateSignature(ConfigurationManager.AppSettings["SecretKey"], orderId);
            ViewBag.Message = signature == localSignature ? "Payment canceled" : "Payment failed";
            showMessage("Success", "You have canceled your previous buy. continue...", "Continue shopping");
            return null;
        }

        public ActionResult CheckPayment(string order, decimal amount)
        {
            string localSignature = CalculateSignature(ConfigurationManager.AppSettings["SecretKey"], order, amount.ToString("0"), ConfigurationManager.AppSettings["AppId"]);
            var client = new HttpClient();
            var request = ConfigurationManager.AppSettings["PaymentInfoAction"];
            var requestObject = new
            {
                applicationId = ConfigurationManager.AppSettings["AppId"],
                orderId = order,
                totalAmount = amount,
                signature = localSignature
            };
            var response = client.PostAsJsonAsync(request, requestObject).Result;
            return Json(response.Content.ReadAsStringAsync(), JsonRequestBehavior.AllowGet);
        }

        public static string CalculateSignature(params string[] args)
        {
            string input = string.Join("", args);
            var sha = new System.Security.Cryptography.SHA256CryptoServiceProvider();
            var hashArray = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));

            return hashArray.Aggregate(string.Empty, (current, b) => current + b.ToString("x2"));
        }

        /// <summary>
        /// Shpws message using toastr on next View.
        /// </summary>
        /// <param name="messageType">Message type (Info, Error, Warning, Success)</param>
        /// <param name="message">Message text</param>
        /// <param name="title"></param>
        private void showMessage(string messageType, string message, string title = null)
        {
            TempData["notificationMessage"] = message;
            TempData["notificationMessageType"] = messageType;
            TempData["notificationMessageTitle"] = title;
        }

    }
}