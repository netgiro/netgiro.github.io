﻿var applicationId = "881e674f-7891-4c20-afd8-56fe2624c4b5";
var secretKey = "YCFd6hiA8lUjZejVcIf/LhRXO4wTDxY0JhOXvQZwnMSiNynSxmNIMjMf1HHwdV6cMN48NX3ZipA9q9hLPb9C1ZIzMH5dvELPAHceiu7LbZzmIAGeOf/OUaDrk2Zq2dbGacIAzU6yyk4KmOXRaSLi8KW8t3krdQSX7Ecm8Qunc/A=";

function formatCurrency(value) {
    return value.toFixed(0) + " kr.";
}

var CartLine = function () {
    var self = this;

    self.category = ko.observable();
    self.product = ko.observable();
    self.quantity = ko.observable(1);

    self.subtotal = ko.computed(function () {
        return self.product() ? self.product().price * parseInt("0" + self.quantity(), 10) : 0;
    });

    // Whenever the category changes, reset the product selection
    self.category.subscribe(function () {
        self.product(undefined);
    });
};

var SubscriptionLine = function() {
    var self = this;

    self.product = ko.observable();
    self.quantity = ko.observable(1);

    self.subtotal = ko.computed(function() {
        return self.product() ? self.product().price * parseInt("0" + self.quantity()) * parseInt("0" + self.product().interval) : 0;
    });
};

var Cart = function () {
    // Stores an array of lines, and from these, can work out the grandTotal
    var self = this;

    self.lines = ko.observableArray(); //Put one line in by default
    self.paymentTypes = ko.observableArray();
    self.paymentType = ko.observable("");
    self.provider = ko.observable(126);
    self.transactionID = ko.observable();
    self.transactionInfo = ko.observable();
    self.Total = ko.observable();
    self.message = ko.observable("Welcome to shop, create secure connection to netgiro and start shopping!");
    self.options = ko.observableArray();
    self.chosenOption = ko.observable(1);
    self.shippingAmount = ko.observable(0);
    self.handlingAmount = ko.observable(0);
    self.isProviderPayingInterest = ko.observable(0);

    self.grandTotal = ko.computed(function () {
        var total = parseFloat(self.shippingAmount()) + parseFloat(self.handlingAmount());
        $.each(self.lines(), function () { total += this.subtotal(); });
        self.Total(total);
        return total;
    });

    self.orderId = ko.computed(function () {
        return new Date().getTime();
    });

    self.signature = ko.computed(function () {
        // Signature should be calculated server side, so that secret key stays a secret
        var input = secretKey + self.orderId() + self.grandTotal().toString().replace(',', '').replace('.', '') + applicationId;
        return CryptoJS.SHA256(input);
    });

    self.payEnabled = ko.computed(function () {
        return (self.lines().length > 0 && self.grandTotal() > 0);
    });

    self.payPartialEnabled = ko.computed(function () {
        return (self.payEnabled() && ((self.grandTotal() / 2999) > 3));
    });

    self.clearCart = function () {
        self.lines.removeAll();
    };

    // Operations
    self.addLine = function () {
        self.lines.push(new CartLine());
    };

    self.removeLine = function (line) {
        self.lines.remove(line);
    };

    self.addSubscription = function () {
        self.lines.push(new SubscriptionLine());
    };

    self.removeSubscription = function (subscription) {
        self.lines.remove(subscription);
    };

    self.showConfirmationFrame = function(e) {
        $("#netgiroFrame").attr("src", "about:blank");
        setTimeout(function() {
            submitForm("#netgiroForm", true, self.chosenOption());
            $("#confirmationFrame").modal('show');
        }, 100);
    };

    self.postConfirmation = function() {
        submitForm("#netgiroFormPost", false, self.chosenOption());
    };
    
    self.iframeConfirmation = function () {
        submitForm("#netgiroFormPost", true, self.chosenOption());
    };
};

var viewModel = new Cart();
ko.applyBindings(viewModel);

function showConfirmation(e) {
    viewModel.checkout();
    $("#confirmation").modal('show');
}



function submitForm(formSelector, iframe, paymentOption) {
    var $form = $(formSelector);
    // clear form
    $form.html("");

    // options
    $form.append(createInput("ApplicationID", applicationId));
    $form.append(createInput("Iframe", iframe));
    $form.append(createInput("Signature", viewModel.signature()));
    $form.append(createInput("PaymentSuccessfulURL", document.location.href + "/Success"));
    $form.append(createInput("PaymentCancelledURL", document.location.href + "/Cancel"));
    $form.append(createInput("ReturnCustomerInfo", false));
    //if (partial) {
    //    $form.append(createInput("UsePartialPayments", true));
    //    $form.append(createInput("MaxNumberOfInstallments", 6));
    //}
    // order header
    $form.append(createInput("OrderId", viewModel.orderId()));
    $form.append(createInput("TotalAmount", parseInt(viewModel.grandTotal())));
    $form.append(createInput("ShippingAmount", parseInt(viewModel.shippingAmount())));
    $form.append(createInput("HandlingAmount", parseInt(viewModel.handlingAmount())));
    $form.append(createInput("PaymentOption", parseInt(paymentOption)));
    //$form.append(createInput("ConfirmationType", 1));
    $form.append(createInput("PaymentConfirmedURL", document.location.href + "/Confirm"));
    // order items

    var iLines = 0;
    var iSubs = 0;
    for (var i = 0; i < viewModel.lines().length; i++) {
        var line = viewModel.lines()[i];
        if (!line.product())
            continue;

        if (line instanceof CartLine) {
            $form.append(createInput("Items[" + iLines + "].ProductNo", line.product().number));
            $form.append(createInput("Items[" + iLines + "].Name", line.product().name));
            $form.append(createInput("Items[" + iLines + "].Description", "Beef pork fatback bacon. Venison meatball bresaola meatloaf chicken ball tip fatback ham hock chuck turducken."));
            $form.append(createInput("Items[" + iLines + "].UnitPrice", parseInt(line.product().price)));
            $form.append(createInput("Items[" + iLines + "].Amount", parseInt(line.subtotal())));
            $form.append(createInput("Items[" + iLines + "].Quantity", parseInt(line.quantity() * 1000)));
            iLines += 1;
        }
        else if (line instanceof SubscriptionLine) {
            $form.append(createInput("Subscriptions[" + iSubs + "].Name", line.product().name));
            $form.append(createInput("Subscriptions[" + iSubs + "].IntervalType", line.product().intervalType));
            $form.append(createInput("Subscriptions[" + iSubs + "].BillingInterval", line.product().interval));
            $form.append(createInput("Subscriptions[" + iSubs + "].IntervalPrice", line.product().price));
            $form.append(createInput("Subscriptions[" + iSubs + "].TrialPeriodDays", line.product().trialPeriod));
            $form.append(createInput("Subscriptions[" + iSubs + "].Quantity", line.quantity()));
            iSubs += 1;
        }
    }
    $form.submit();
}

function createInput(name, value) {
    return $("<input type='hidden' />")
                .attr("name", name)
                .val(value);
}

//after modal is shown, focus on first input
$('.modal').on('shown', function (e) {
    $(this).find("input:visible:first").focus();
});
