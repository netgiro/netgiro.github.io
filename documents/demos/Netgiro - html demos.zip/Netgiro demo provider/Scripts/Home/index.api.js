﻿function formatCurrency(value) {
    return "ISK " + value.toFixed(2);
}

function PaymentType(t) {
    var self = this;
    self.paymentMethodId = t.PaymentMethodId;
    self.name = t.Name;
}

function PaymentOption(t) {
    var self = this;
    self.paymentOptionId = t.PaymentOptionId;
    self.name = t.Name;
    self.amount = t.TotalAmount;
}

var CartLine = function () {
    var self = this;
    self.category = ko.observable();
    self.product = ko.observable();
    self.quantity = ko.observable(1);
    self.subtotal = ko.computed(function () {
        return self.product() ? self.product().price * parseInt("0" + self.quantity(), 10) : 0;
    });

    // Whenever the category changes, reset the product selection
    self.category.subscribe(function () {
        self.product(undefined);
    });
};

var Cart = function () {
    // Stores an array of lines, and from these, can work out the grandTotal
    var self = this;
    self.lines = ko.observableArray([new CartLine()]); //Put one line in by default
    self.paymentTypes = ko.observableArray();
    self.paymentType = ko.observable("");
    self.provider = ko.observable(126);
    self.transactionID = ko.observable();
    self.transactionInfo = ko.observable();
    self.Total = ko.observable();
    self.message = ko.observable("Welcome to shop, login (user: demo, pass: demo123) and start shopping!");
    self.options = ko.observableArray();
    self.chosenOption = ko.observable(0);

    self.grandTotal = ko.computed(function () {
        var total = 0;
        $.each(self.lines(), function () { total += this.subtotal(); });
        self.Total(total);
        return total;
    });

    self.shippingAmount = ko.observable(0);

    self.handlingAmount = ko.observable(0);

    self.clearCart = function () {
        self.lines.removeAll();
    };

    // Operations
    self.addLine = function () {
        self.lines.push(new CartLine());
    };
    self.removeLine = function (line) { self.lines.remove(line); };

    self.buy = function () {
        $.ajax({
            url: $('#shop-cart').attr('data-service-url'),
            type: "POST",
            data: JSON.stringify({ option: self.chosenOption() }),
            dataType: 'html',
            contentType: 'application/json'
        }).success(function () {
            self.clearCart();
            alert("Order submited!");
        }).error(function () {
            alert("Error!");
        });
    };
    
    self.buy2 = function () {
        $.ajax({
            url: $('#shop-cart').attr('data-service2-url'),
            type: "POST",
            data: JSON.stringify({ option: self.chosenOption() }),
            dataType: 'html',
            contentType: 'application/json'
        }).success(function (data) {
            if (data.success) {
                self.clearCart();
                alert("Order submited!");
            }
            alert(data.message);
        }).error(function (data) {
            alert(data.message);
        });
    };

    self.checkout = function () {
        var dataToSave = $.map(self.lines(), function (line) {
            return line.product() ? {
                ProductNo: line.product().number,
                ProductDescription: line.product().name,
                Quantity: line.quantity(),
                Amount: line.product().price,
            } : undefined;
        });

        $.ajax({
            url: $('#shop-cart').attr('data-checkout-url'),
            type: "POST",
            data: JSON.stringify({ cartItems: dataToSave }),
            contentType: 'application/json'
        }).success(function (data) {
            self.options.removeAll();
            $.map(data.options, function (t) {
                self.options.push(new PaymentOption(t, self));
            });
            self.message(data.message);
        });
    };
};

var viewModel = new Cart();
ko.applyBindings(viewModel);

function showConfirmation() {
    viewModel.checkout();
    $("#confirmation").modal('show');
}

//after modal is shown, focus on first input
$('.modal').on('shown', function () {
    $(this).find("input:visible:first").focus();
});