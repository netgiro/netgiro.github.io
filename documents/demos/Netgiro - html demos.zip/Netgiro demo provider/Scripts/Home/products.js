﻿// Some of the Knockout examples use this data
var sampleProductCategories = [
  {
      "products": [
        {
            "number": 1,
            "name": "1948 Porsche 356-A Roadster",
            "price": 539
        },
        {
            "number": 2,
            "name": "1948 Porsche Type 356 Roadster",
            "price": 6216
        },
        {
            "number": 3,
            "name": "1952 Alpine Renault 1300",
            "price": 9858
        },
        {
            "number": 4,
            "name": "1952 Citroen-15CV",
            "price": 7282
        },
        {
            "number": 5,
            "name": "1956 Porsche 356A Coupe",
            "price": 983
        },
        {
            "number": 6,
            "name": "1957 Corvette Convertible",
            "price": 6993
        },
        {
            "number": 7,
            "name": "1957 Ford Thunderbird",
            "price": 3421
        },
        {
            "number": 8,
            "name": "1958 Chevy Corvette Limited Edition",
            "price": 1591
        },
        {
            "number": 9,
            "name": "1961 Chevrolet Impala",
            "price": 3233
        },
        {
            "number": 10,
            "name": "1962 LanciaA Delta 16V",
            "price": 10342
        },
        {
            "number": 11,
            "name": "1965 Aston Martin DB5",
            "price": 6596
        },
        {
            "number": 12,
            "name": "1966 Shelby Cobra 427 S/C",
            "price": 2918
        },
        {
            "number": 13,
            "name": "1968 Dodge Charger",
            "price": 7516
        },
        {
            "number": 14,
            "name": "1968 Ford Mustang",
            "price": 9534
        },
        {
            "number": 15,
            "name": "1969 Chevrolet Camaro Z28",
            "price": 5051
        },
        {
            "number": 16,
            "name": "1969 Corvair Monza",
            "price": 8914
        },
        {
            "number": 17,
            "name": "1969 Dodge Charger",
            "price": 5873
        },
        {
            "number": 18,
            "name": "1969 Dodge Super Bee",
            "price": 4905
        },
        {
            "number": 19,
            "name": "1969 Ford Falcon",
            "price": 8305
        },
        {
            "number": 20,
            "name": "1970 Chevy Chevelle SS 454",
            "price": 4924
        },
        {
            "number": 21,
            "name": "1970 Dodge Coronet",
            "price": 3237
        },
        {
            "number": 22,
            "name": "1970 Plymouth Hemi Cuda",
            "price": 3192
        },
        {
            "number": 23,
            "name": "1970 Triumph Spitfire",
            "price": 9192
        },
        {
            "number": 24,
            "name": "1971 Alpine Renault 1600s",
            "price": 3858
        },
        {
            "number": 25,
            "name": "1972 Alfa Romeo GTA",
            "price": 8568
        },
        {
            "number": 26,
            "name": "1976 Ford Gran Torino",
            "price": 7349
        },
        {
            "number": 27,
            "name": "1982 Camaro Z28",
            "price": 4653
        },
        {
            "number": 28,
            "name": "1982 Lamborghini Diablo",
            "price": 1624
        },
        {
            "number": 29,
            "name": "1985 Toyota Supra",
            "price": 5701
        },
        {
            "number": 30,
            "name": "1992 Ferrari 360 Spider red",
            "price": 779
        },
        {
            "number": 31,
            "name": "1992 Porsche Cayenne Turbo Silver",
            "price": 6978
        },
        {
            "number": 32,
            "name": "1993 Mazda RX-7",
            "price": 8351
        },
        {
            "number": 33,
            "name": "1995 Honda Civic",
            "price": 9389
        },
        {
            "number": 34,
            "name": "1998 Chrysler Plymouth Prowler",
            "price": 10151
        },
        {
            "number": 35,
            "name": "1999 Indy 500 Monte Carlo SS",
            "price": 5676
        },
        {
            "number": 36,
            "name": "2001 Ferrari Enzo",
            "price": 9559
        },
        {
            "number": 37,
            "name": "2002 Chevy Corvette",
            "price": 6211
        }
      ],
      "name": "Classic Cars"
  },
    {
        "products": [
          {
              "number": 38,
              "name": "1900s Vintage Bi-Plane",
              "price": 3425
          },
          {
              "number": 39,
              "name": "1900s Vintage Tri-Plane",
              "price": 3623
          },
          {
              "number": 40,
              "name": "1928 British Royal Navy Airplane",
              "price": 6674
          },
          {
              "number": 41,
              "name": "1980s Black Hawk Helicopter",
              "price": 7727
          },
          {
              "number": 42,
              "name": "ATA: B757-300",
              "price": 5933
          },
          {
              "number": 43,
              "name": "America West Airlines B757-200",
              "price": 688
          },
          {
              "number": 44,
              "name": "American Airlines: B767-300",
              "price": 5115
          },
          {
              "number": 45,
              "name": "American Airlines: MD-11S",
              "price": 3627
          },
          {
              "number": 46,
              "name": "Boeing X-32A JSF",
              "price": 3277
          },
          {
              "number": 47,
              "name": "Corsair F4U ( Bird Cage)",
              "price": 2934
          },
          {
              "number": 48,
              "name": "F/A 18 Hornet 1/72",
              "price": 544
          },
          {
              "number": 49,
              "name": "P-51-D Mustang",
              "price": 490
          }
        ],
        "name": "Planes"
    }
];

var sampleSubscriptions = [
    {
        "name": "Monthly subscription",
        "intervalType": 2,
        "price": 1000,
        "trialPeriod": 0,
        "interval": 1,
        "intervalName": "Month"
    },
    {
        "name": "Weekly subscription",
        "intervalType": 1,
        "price": 200,
        "trialPeriod": 0,
        "interval": 1,
        "intervalName": "Week"
    },
    {
        "name": "Yearly subscription",
        "intervalType": 3,
        "price": 12000,
        "trialPeriod": 0,
        "interval": 1,
        "intervalName": "Year"
    },
    {
        "name": "Yearly subscription with trial",
        "intervalType": 3,
        "price": 12000,
        "trialPeriod": 14,
        "interval": 1,
        "intervalName":"Year"
    },
    {
        "name": "Monthly subscription with trial",
        "intervalType": 2,
        "price": 1000,
        "trialPeriod": 14,
        "interval": 1,
        "intervalName": "Month"
    },
    {
        "name": "Quartery subscription",
        "intervalType": 2,
        "price": 1000,
        "trialPeriod": 14,
        "interval": 3,
        "intervalName": "Month"
    }];