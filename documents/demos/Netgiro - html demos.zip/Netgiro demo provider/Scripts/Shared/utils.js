﻿$(document).ready(function () {
    $.ajaxSetup({
        cache: false
    });

    $(".tooltip-element").tooltip();

    //toastr messages
    if (notificationMessage)
        if (notificationMessageType === "Warning")
            toastr.warning(notificationMessage, notificationMessageTitle);
        else if (notificationMessageType === "Success")
            toastr.success(notificationMessage, notificationMessageTitle);
        else if (notificationMessageType === "Info")
            toastr.info(notificationMessage, notificationMessageTitle);
    if (notificationMessageType === "Error")
        toastr.error(notificationMessage, notificationMessageTitle);
   
});